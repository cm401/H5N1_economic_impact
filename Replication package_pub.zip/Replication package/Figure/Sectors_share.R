library(treemap)

 ### DATA FROM QO GTAP 11C ###

df <- data.frame(
  qo = c("GrainsCrops","Drp","Meats","Cattle","Rwmk","MeatLstk","ProcFood","Mnfc","OtherSec"),
  US = c(236274.14,136428.77,130113.98,64570.40,40203.74,204408.20,650409.13,5272834.00,25330356.00),
  stringsAsFactors = FALSE
)

name_map <- c(
  GrainsCrops = "Grains and Crops",
  Drp         = "Dairy Products",
  Meats       = "Meat Products",
  Cattle      = "Cattle",
  Rwmk        = "Raw Milk",
  MeatLstk    = "Other Meat",
  ProcFood    = "Processed Food",
  Mnfc        = "Manufacturing",
  OtherSec    = "Other Sectors"
)
df$qo_disp <- name_map[df$qo]

df <- df[match(
  c("GrainsCrops","Drp","Meats","Cattle","Rwmk","MeatLstk","ProcFood","OtherSec","Mnfc"),
  df$qo
), ]

total <- sum(df$US)
df$share <- 100 * df$US / total
df$label <- sprintf("%s\n%s (%.2f%%)",
                    df$qo_disp,
                    formatC(df$US, format = "f", digits = 2, big.mark = ","),
                    df$share)

# Colors (same as before)
my_colors <- c(
  "#CD5C5C", # 1. Cattle (Salmon)
  "#DAA520", # 2. Dairy Products (Dark Gold)
  "#FFD700", # 3. Grains and Crops (Light Gold)
  "#00A000", # 4. Manufacturing (Darker Green to match image)
  "#FF6347", # 5. Meat Products (Reddish)
  "#87CEFA", # 6. Other Meat (Light Blue)
  "#6495ED", # 7. Other Sectors (Blue)
  "#DDA0DD", # 8. Processed Food (Pink)
  "#FFB6C1"  # 9. Raw Milk (Light Pink)
)

# Treemap
# PDF (vector)
folder_figure <-  '<insert_your_local_path_here>/Replication package/Figure/'

pdf(file.path(folder_figure, "Plot_share_sectors.pdf"),
    width =8, height = 11, useDingbats = FALSE)
treemap(
  df,
  index  = "label",
  vSize  = "US",
  type   = "index",
  palette = my_colors,
  title = "",
  fontsize.labels = 13,
  fontcolor.labels = "white",
  fontface.labels = 2,
  align.labels = c("center", "center"),
  border.col = "white",
  bg.labels = "transparent",
  inflate.labels = FALSE
)
dev.off()

